# College Data

For more information about the data format or how the data was created, visit [this page](https://libguides.library.kent.edu/ld.php?content_id=11205386).

## Credit to:

Statistical Consulting at University Libraries
Room 812, University Library, Kent State University