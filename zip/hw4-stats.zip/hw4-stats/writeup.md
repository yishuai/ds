# Statistics Write Up

## Part 1: Regression

All questions in this section pertain to the `bike-sharing.csv` dataset.

#### 1. (5 points)
**Question**:
Interpret the co-efficient for `weathersit` according to simple linear regression. Using plain English, what does this coefficient mean? (one or two sentences should be sufficient)

**Answer**:
*Your answer here*

#### 2. (9 points)
**Question**:
Compare the co-efficient on `weathersit` in a simple regression model (only one independent variable) and the coefficient in the multiple regression model that includes all variables.
- Did the coefficient go up or down?
- Why do you think this is the case?
 
**Answer**:
*Your answer here*

#### 3. (9 points)
**Question**:
Which variable would you say is the "most important" for predicting bike usage? Defend your choice.

**Answer**:
*Your answer here*

#### 4. (9 ponts)
**Question**:
- In plain English, what is R-squared value?
- What does the R-squared value imply about multiple linear regression models when compared to simple linear regression models?
- Does higher R-squared value always mean that a model is better? Why? How should you best utilize R-squared to examine the goodness of fit for your linear model?

**Answer**:
*Your answer here*

#### 5. (8 points)
**Question**:
Is there a difference between training and testing MSE? Why is comparing this important?

**Answer**:
*Your answer here*

## Part 2: Statistical Tests

All questions in this section pertain to the `college-data.csv` dataset. For each of the scenarios below, you are expected to answer the following questions:
- What is your null hypothesis? What is your alternative hypothesis?
- What test do we use to answer this question? Why?
- Can we reject the null hypothesis? Why? Be sure to mention the numbers that are part of your reasoning.

We will use the significance level α = 0.05 for all the scenarios.

**Note**: We acknowledge that the binary framework of gender in this dataset does not remotely represent all the possible gender identities that people may have.

### Scenario One (12 points)
In our sample data, students reported their typical time to run a mile, and whether or not they were an athlete. We want to know whether the average time to run a mile is different for athletes versus non-athletes.

**Answer**:
*Your answer here*

### Scenario Two (12 points)
The mean height of U.S. adults ages 20 and older is about 66.5 inches (69.3 inches for males, 63.8 inches for females). In our sample data, we have a sample of 435 college students from a single college. We want to determine whether the mean height of students at this college is significantly different than the mean height of U.S. adults ages 20 and older.

**Answer**:
*Your answer here*

### Scenario Three (12 points)
In the sample data, the students also reported their class quartile (1,2,3,4 for the first, second, third and fourth quartile), as well as whether they live on campus. We want to test if there is a relationship between one's class quartile and whether they live on campus.

Note: Their class quartile is denoted in the dataset as "Rank".

**Answer**:
*Your answer here*

### Scenario Four (12 points)
The students in the sample completed all 4 placement tests for four subject areas - English, Reading, Math, and Writing - when they enrolled in the university. The scores are out of 100 points, and are present in the dataset. We want to test if there was a significant difference between the average of the English test scores and that of the Math test scores.

**Answer**:
*Your answer here*

### Scenario Five (12 points)
In the sample dataset, respondents were asked their gender and whether or not they were a cigarette smoker. There were three answer choices: Nonsmoker, Past smoker, and Current smoker. We want to test the relationship between smoking behavior (nonsmoker, current smoker, or past smoker) and gender (male or female).

**Answer**:
*Your answer here*



## Part 3: Socially Responsible Computing

#### 1. (5 points)
**Question**
Explain how Simpson's Paradox occurs in the context of the exercise vs. disease example. Why should we choose to separate the data into 2 groups for this specific dataset/question?

**Answer**
*Your answer here*

#### 2. (7 points)
a.
**Question**
In a few sentences, present and justify statistical results supporting the claim that “Democrats are bad for the economy.”

**Answer**
*Your answer here*

b.
**Question**
In a few sentences, present and justify statistical results supporting the claim that “Republicans are bad for the economy.”

**Answer**
*Your answer here*

c.
**Question**
Write a short reflection about your above experiments with different variable combinations and political claims. Whether specific to the data or broadly applicable to statistical analysis of all kinds, what should you avoid or emphasize if you present or publish the results of such an analysis?

**Answer**
*Your answer here*



#### 3. (6 points)
a. 
**Question**
What factors might be influencing the `bike-sharing.csv` data that are not being shown in the dataset? List at least 3 possible factors. The factors could be additional variables or factors that are not quantifiable.

**Answer**
*Your answer here*

b.
**Question**
List one category for which it could be helpful to separate the `bike-sharing.csv` data into groups before analyzing it. This category may or may not be represented in the existing dataset. Describe a context (project, question, goals, etc.) for which separating the data by that category is important and explain why separating the data is the right choice for that context.

**Answer**
*Your answer here*

c.
**Question**
Explain at least one way that information in the bikeshare reading impacts how you should interpret `bike-sharing.csv` or present your findings.

**Answer**
*Your answer here*


#### 3. (2 points)

Please fill out this form! [SRC Mid-Semester Feedback Form](https://docs.google.com/forms/d/e/1FAIpQLSempkWgECNhzIHYYiNnCV20eQUU0eZtR6cz7BKiYLr8buIr4w/viewform?usp=sf_link)