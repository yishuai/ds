# %% [markdown]
# ## 2. Hypothesis Testing

# ### 2.1. Introduction to Hypothesis Testing
# -   **Hypothesis Testing** – use the statistics obtained from a sample to say whether a particular assumption about the population parameter is correct or not.

# ### 2.2. Hypothesis Testin
#   
# A $p$-value is calculated from the test statistic; it is the probability of finding data as extreme or more extreme than what we have observed, given that the null hypothesis is true. In other words, a $p$-value can be used to answer this question: *If the null hypothesis is true, is my data unusual?* When a $p$-value is small, the answer is "*yes*". And when the answer is "*yes*", we are generally inclined to take this as evidence against the null hypothesis.
# ## 3. Hypothesis Testing in Python using Hollywood Movies Dataset
import numpy as np
import pandas as pd

imdb_csv_url = "./data/IMDB-Movie-Data.csv"
imdb_df = pd.read_csv(imdb_csv_url)
imdb_df = imdb_df.dropna()  # Drop rows with missing values
imdb_df.head(n=3)  # View the first few rows of the dataframe to see how it looks

# ### 3.1. Statistical tests: $Z$-test $\&$ $T$-test
# - **t-test**: used when the population parameters (mean and standard deviation) are not known.
# - **z-test**: used when the population parameters (mean and standard deviation) are known.

# #### 3.1.1 One sample $z$-test example

# - **one sample**: comparing the sample mean with the population mean.
# - **z-test**: used when the population parameters (mean and standard deviation) are known.
import matplotlib.pyplot as plt

plt.hist(imdb_df['Metascore'], bins=10)
plt.show()

# Looks reasonably normally distributed, so we're good to go. 
# def manual_z_test_1samp(sample, population):
  
  n = np.shape(sample)[0]
  sample_mean = np.mean(sample)

  population_mean = np.mean(population)
  variance = np.var(population)
  
  print(f"n={n}, sample_mean={sample_mean:.5f}, population_mean={population_mean:.5f}, variance={variance:.5f}")
  
  z = (sample_mean - population_mean) / (np.sqrt(variance/(n)))
  return z

# We can now use this function to find the $z$-test statistic by passing in our sample and population as inputs:

metascore_2015 = imdb_df[imdb_df['Year']==2015]['Metascore']
print(f"z={manual_z_test_1samp(sample=metascore_2015, population=imdb_df['Metascore']):.5f}")

# **Two Tail*
from statsmodels.stats import weightstats as stests

test_statistic, p_value = stests.ztest(x1=metascore_2015, value=np.mean(imdb_df['Metascore']))
print(f"test_statistic={test_statistic:.5f}")
print(f"p_value={p_value:.5f}")

# You may notice these $z$-scores are very similar but not identical. This is because in our manual function we used the actual variance of the population whereas in the library function it uses the sample variance as an estimation of the population variance.
import scipy.stats as stats

def reject_or_not(test_statistic, lower_crit_val, upper_crit_val):
  print(f"test_statistic={test_statistic:.5f}, lower_critical_value={lower_crit_val:.5f}, upper_critical_value={upper_crit_val:.5f}")
  if lower_crit_val <= test_statistic <= upper_crit_val:
    print("We therefore fail to reject the null hypothesis and cannot accept the alternate hypothesis.")
  else:
    print("We therefore reject the null hypothesis and accept the alternate hypothesis.")

lower_crit_val, upper_crit_val = stats.norm.ppf(0.025), stats.norm.ppf(0.975)
reject_or_not(test_statistic, lower_crit_val, upper_crit_val)

# However, we could also just use the $p$-value by itself

print(f"p_value={p_value:.5f}")

# **Since the $p$-value is higher than $0.05$ ($5\%$) we fail to reject the null hypothesis, and cannot accept the alternate hypothesis i.e., there does not seem to be a significant difference in the Metascore ratings of movies released in the year 2015.**

# #### 3.1.2 Two sample $t$-test example
# - $H_0$: There is no significant difference in the `Metascore` ratings of movies released in the `year` $2006$ and $2016$.
# - You can read more about the two sample $t$-test [here](https://www.cliffsnotes.com/study-guides/statistics/univariate-inferential-tests/two-sample-t-test-for-comparing-two-means) and the two sample $z$-test [here](https://www.cliffsnotes.com/study-guides/statistics/univariate-inferential-tests/two-sample-z-test-for-comparing-two-means). 
# - The generic formula that we give here for the two sample $t$-test essentially covers all cases, however, it should be noted that this formula may be simplified under certain conditions which you can research on your own if you are interested ([Google 🔍](https://www.google.com/) & [Wikipedia 📖](https://www.wikipedia.org/) are your friends).

def manual_t_test_ind(a, b):
  n_a = np.shape(a)[0]
  n_b = np.shape(b)[0]
  print(f"na={n_a}, a_mean={np.mean(a):.5f}, a_var={np.var(a):.5f}, nb={n_b}, b_mean={np.mean(b):.5f}, b_var={np.var(b):.5f}")
  t = (np.mean(a) - np.mean(b)) / (np.sqrt((np.var(a))/n_a + (np.var(b))/n_b))
  return t

metascore_2006 = imdb_df[imdb_df['Year']==2006]['Metascore']
metascore_2016 = imdb_df[imdb_df['Year']==2016]['Metascore']

print(f"t={manual_t_test_ind(a=metascore_2006, b=metascore_2016):.5f}")

# For calculating the critical values we require the degree of freedom for the test, i.e., [the number of values in the final calculation of a statistic that are free to vary](http://www.animatedsoftware.com/statglos/sgdegree.htm). This is calculated as:

def degrees_of_freedom(a, b):
  v_1 = np.var(a)
  v_2 = np.var(b)
  n_1 = np.shape(a)[0]
  n_2 = np.shape(b)[0]

  nr = ((v_1/n_1) + (v_2/n_2))**2
  dr = (((v_1/n_1)**2)/(n_1 - 1)) + (((v_2/n_2)**2)/(n_2 - 1))
  return nr / dr

degrees_of_freedom = degrees_of_freedom(a=metascore_2006, b=metascore_2016)
print(f"degrees_of_freedom={degrees_of_freedom:.5f}")

# Thus the degree of freedom comes out to be $70.195120$.
test_statistic, p_value = stats.ttest_ind(a=metascore_2006, b=metascore_2016, equal_var=False)
print(f"t-score = {test_statistic:.5f}, p-value = {p_value:.5f}")

lower_crit_val, upper_crit_val = stats.t.ppf(0.025, degrees_of_freedom), stats.t.ppf(0.975, degrees_of_freedom)

reject_or_not(test_statistic, lower_crit_val, upper_crit_val)

# If however we had dependant samples (we have repeated measurements i.e., one sample with two measurement occasions or when there are two samples that have been "matched" or "paired") we would have used [scipy.stats.**ttest_rel**](https://docs.scipy.org/doc/scipy/reference/generated/scipy.stats.ttest_rel.html) instead of [scipy.stats.**ttest_ind**](https://docs.scipy.org/doc/scipy/reference/generated/scipy.stats.ttest_ind.html). 
# print(f"p_value={p_value}")

# **The $p$-value for the above test is $0.0423$, which is less than $0.05$. Therefore we reject the null hypothesis that the two samples have the same mean, and we accept the alternate hypothesis i.e., there does appear to be a difference in the mean Metascore of the movies released in 2006 compared to 2016.**

# ### 3.2 Chi-squared ($\chi^2$) Test
#     - Pearson's $\chi^2$ goodness-of-fit test
#     - a variable with more than 2 categories
#     - determine if sample data matches a population
#     - Read more about this test [here](http://hamelg.blogspot.com/2015/11/python-for-data-analysis-part-25-chi.html)

#     - test the statistical relationship between two categorical variables
#     - The hypotheses for a Chi-squared test are as follows:
#       - $H_A$: There is an association between the two variables
#       - $H_0$: The two variables are independent
# # - The data is usually displayed in a cross-tabulation format with each row representing a level (group) for one variable and each column representing a level (group) for another variable.
# - The test is comparing the observed observations to the expected observations.
# - ⚠️If you are confused about what a "cross-tabulation format" is, don't worry, we will go over an example in 3.2.1. 
# - If, after going through this, you are still confused, here is a [short video example](https://www.khanacademy.org/math/ap-statistics/chi-square-tests/chi-square-tests-two-way-tables/v/chi-square-test-association-independence) you can come back to.

# - There are a few assumptions that need to be meet in order for the results of the Chi-square test to be trusted. We won't list them but you can read them [here](https://statistics.laerd.com/spss-tutorials/chi-square-test-for-association-using-spss-statistics.php
# ).
# under the null hypothesis.
# - A smalled chi-squared value - corresponding to a higher $p$-value - will not reject this claim of independence

# #### 3.2.1 Chi-squared ($\chi^2$) Independence Test Example
# imdb_df["Over 200 mill revenue"] = imdb_df["Revenue (Millions)"] > 100
imdb_df.sample(n=3)  # View 3 random rows

# Next lets create a cross table between the approriate columns:

cross_table = pd.crosstab(imdb_df["Over 200 mill revenue"], imdb_df["Year"], margins=True)
cross_table

years = list(cross_table.columns)[:-1]  # Lets save the year col names into a variable
years

observed = cross_table.iloc[0:-1, 0:-1] 
observed.index = ['False', 'True']  # Set row names
observed.columns = years  # Set columns names
observed

# #### 根据各行和各列的 All，计算各 Cell 的 Expected
# np.outer(cross_table["All"][:-1], cross_table.loc["All"][:-1])

# 总样本数
cross_table.iloc[-1,-1]

expected = np.outer(cross_table["All"][:-1], cross_table.loc["All"][:-1]) / cross_table.iloc[-1,-1]
expected = pd.DataFrame(expected, index=['False', 'True'], columns=years)
expected

# 每一列的总数，就是那一年的总数
expected.sum()

# 整个总数还是样本数
expected.sum().sum()

# Lets use [scipy.stats.chi2.**ppf**](https://docs.scipy.org/doc/scipy/reference/generated/scipy.stats.chi2.html) to get a critical value instead of manually looking it up using a [Chi-square Distribution Table](https://people.smp.uq.edu.au/YoniNazarathy/stat_models_B_course_spring_07/distributions/chisqtab.pdf):

chi_sq_test_statistic = (((observed-expected)**2)/expected).sum().sum()
# We call .sum() twice: once to get the column sums and a second time to add the column sums together, returning the sum of the entire 2D table.

critical_value = stats.chi2.ppf(q=0.95, # Find the critical value for 95% confidence
                                df=10)  # df = (number of row categories - 1) * (number of column categories - 1) 
                                        #    = 1 * 10 = 10

print(f"chi_sq_test_statistic={chi_sq_test_statistic}, critical_value={critical_value}")

# Test statistic is greater than the critical value

# - There is enough evidence to suggest there is a relationship between the year and the number of movies with a revenue above 100 million
p_value = 1 - stats.chi2.cdf(x=chi_sq_test_statistic, # Find the p-value
                             df=10)            # df = (number of row categories - 1) * (number of column categories - 1) 
                                               #    = 1 * 10 = 10
print(f"p_value={p_value}")

# $𝑝$-value is less than 0.05

chi_squared, p_value, degrees_of_freedom, expected = stats.chi2_contingency(observed=observed)
print(f"chi_squared={chi_squared}, p_value={p_value}, degrees_of_freedom={degrees_of_freedom}")

# ## 4. Real world application of what we have learnt
import pandas as pd

arrests_csv_url = "./data/arrests_data.csv"
arrests_df = pd.read_csv(arrests_csv_url)
arrests_df.head(n=2)  # We can use head to view the first couple rows for a sanity check

# cases_csv_url = "https://stats-lab-data.surge.sh/cases_data.csv"
cases_csv_url = "./data/cases_data.csv"
cases_df = pd.read_csv(cases_csv_url)
cases_df.head(n=2)  # We can use head to view the first couple rows for a sanity check

# ### 4.1. Data Processing

# Add columns in our dataframe with the relevant variables. 
# - one indicating whether an arrestee has an address or is homeless
# - one for whether the case went forward
from collections import Counter 

arrests_df["is_homeless"] = arrests_df["from_address"] == "No Permanent Address"
print(Counter(arrests_df["is_homeless"]))

all_cases_set = set(cases_df["case_number"])  # We use a set to ensure O(1) lookup time for `isin` 
arrests_df["became_case"] = arrests_df["case_number"].isin(all_cases_set)
print(len(arrests_df))

arrests_df.drop_duplicates(subset=["id", "case_number", "is_homeless", "became_case", "arresting_officers"], inplace=True)
print(len(arrests_df))

arrests_df.sample(n=3)  # View a random sample of rows. Scroll right to see the new columns you created

# ### 4.2. Testing hypothesis question 1

import scipy.stats as stats

contingency_cross_table = pd.crosstab(arrests_df["?"], arrests_df["?"])
contingency_cross_table

f_obs = np.array([contingency_cross_table.iloc[?].values,
                  contingency_cross_table.iloc[?].values])
f_obs

?, ?, ?, ? = stats.?(f_obs)
print(f"The p-value is: {?:.5f}")

# **Explain to your TA the results of above test and why you think we used it?**

# ### 4.3. Adding new `officer_cnt` column
arrests_df["officer_cnt"] = arrests_df["arresting_officers"].str.strip().str.split(', ').fillna('').apply(len)
arrests_df.head()

# ### 4.4. Testing hypothesis question 2

homeless_rows = arrests_df.loc[arrests_df["?"] == ?]
non_homeless_rows = arrests_df.loc[arrests_df["?"] == ?]

?, ? = stats.?(homeless_rows["?"], non_homeless_rows["?"])

print(f"The p-value is: {?:.5f}")

# **Explain the results of above test and why you think we used it?**

# # 🎉 Congratulations you finished the lab 